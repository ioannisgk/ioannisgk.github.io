from selenium.webdriver.common.by import By


class Locators(object):
    HEADER_TEXT = (By.XPATH, "//h1")

    SEARCH_FIELD = (By.ID, "search")

    SUBMIT_BUTTON = (By.XPATH, "//*[@id='search_bar']/div[1]/div[2]/button")

    SEARCH_BUTTON = (By.XPATH, "/html/body/header/div[4]/ul/li[7]/a")

    SIGN_IN_BUTTON = (By.XPATH, "/html/body/div[1]/header/div[1]/div/ul/li[2]/a")

    USERNAME_INPUT = (By.ID, "email")
    GIVEN_EMAIL = "mc.cullagh.hoffman@gmail.com"
    PASSWORD_INPUT = (By.ID, "pass")
    PASSWORD = "A1s2d3f4g5h6j7k8l9"

    PRODUCT = (By.CSS_SELECTOR,
               "#maincontent > div.columns > div.column.main > div.search.results > div.products.wrapper.grid.products-grid > ol > li:nth-child(1) > div > a > span > span > img")
    COLOR_BLACK = (
        By.CSS_SELECTOR, "#product-options-wrapper > div > div > div.swatch-attribute.color > div > div:nth-child(1)")
    SIZE_SMALL = (
        By.CSS_SELECTOR, "#product-options-wrapper > div > div > div.swatch-attribute.size > div > div:nth-child(2)")
    ADD_TO_THE_BASKET_BUTTON = (By.CSS_SELECTOR, "#product-addtocart-button")

    CART_ICON = (By.CSS_SELECTOR, "body > div.page-wrapper > header > div.header.content > div.minicart-wrapper > a")
    GO_TO_CHECKOUT_BUTTON = (By.CSS_SELECTOR, "#top-cart-btn-checkout")

    CREATE_NEW_ADDRESS_BUTTON = (By.CSS_SELECTOR, "#checkout-step-shipping > button")

    STREET_ADDRESS_INPUT = (By.NAME, "street[0]")
    STREET_ADDRESS = "Agiou Georgiou 5"
    CITY_NAME_INPUT = (By.NAME, "city")
    CITY_NAME = "Thessaloniki"
    POSTAL_CODE_INPUT = (By.NAME, "postcode")
    POSTAL_CODE = "57001"
    COUNTRY = "country_id"
    GREECE = "Greece"
    REGION = "region_id"
    KENTRIKI_MAKEDONIA = "Kentriki Makedonia"
    TELEPHONE_INPUT = (By.NAME, "telephone")
    TELEPHONE = "2310475556"

    SAVE_SHIPPING_FORM_BUTTON = (By.XPATH, "/html/body/div[2]/aside[2]/div[2]/footer/button[1]")

    ELTA_SHIPPING_COMPANY = (By.XPATH, "//*[@id='s_method_tablerate_bestway']")
    UPS_SHIPPING_COMPANY = (By.XPATH, "//*[@id='s_method_flatrate_flatrate']")
    FREE_SHIPPING_OPTION = (By.XPATH, "//*[@id='s_method_freeshipping_freeshipping']")

    NEXT_BUTTON = (By.XPATH, "//*[@id='shipping-method-buttons-container']/div/button")

    PLACE_ORDER_BUTTON = (By.XPATH, "//*[@id='checkout-payment-method-load']/div/div/div[4]/div[2]/div[4]/div/button")

    CASH_ON_DELIVERY_OPTION = (By.XPATH, "//*[@id='cashondelivery']")
    BANK_TRANSFER_OPTION = (By.XPATH, "//*[@id='banktransfer']")

    ORDER_ID = "//*[@id='maincontent']/div[3]/div/div[2]/p[1]"
