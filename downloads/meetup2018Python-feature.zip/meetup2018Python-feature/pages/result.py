import time

from driver import Browser
from pages.actions.actions import Actions
from pages.constants import Locators


class ResultsPage(Browser):
    # Result Page Actions

    def __init__(self):
        self.action = Actions()

    def he_will_choose_a_product_and_then_will_add_it_into_the_basket(self):
        self.choose_product()
        try:
            self.action.click_element(*Locators.ADD_TO_THE_BASKET_BUTTON)
            print("[DONE] -- I added successfully the product into the basket.")
            time.sleep(2)
        except Exception as e:
            print("[ERROR] -- I couldn't add the product to the basket because --> "+str(e)+"")

    def choose_product(self):
        try:
            time.sleep(2)
            self.action.click_element(*Locators.PRODUCT)
            self.choose_variants()
            time.sleep(2)
            print("[DONE] -- I successfully chose the product.")
        except Exception as e:
            print("[ERROR] -- I couldn't click on the product because --> "+str(e)+"")

    def choose_variants(self):
        try:
            self.action.click_element(*Locators.COLOR_BLACK)
            self.action.click_element(*Locators.SIZE_SMALL)
            print("\n[DONE] -- I chose size [black] and color [small] selected successfully.")
        except Exception as e:
            print("[ERROR] -- Issue with color or size because of --> "+str(e)+"")
