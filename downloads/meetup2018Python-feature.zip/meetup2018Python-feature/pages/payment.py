import time

from driver import Browser
from pages.actions.actions import Actions
from pages.constants import Locators


class PaymentPage(Browser):
    # Payment Page Actions

    def __init__(self):
        self.action = Actions()

    def option(self, payment_option_id):
        time.sleep(3)
        self.choose_a_payment_option(payment_option_id)
        time.sleep(2)
        self.driver.execute_script("window.scrollTo(0, 200);")
        time.sleep(1)
        self.action.click_element(*Locators.PLACE_ORDER_BUTTON)
        time.sleep(7)

    def choose_a_payment_option(self, payment_id):

        # print("THE PAYMENT ID IS ------>  "+payment_id+"")

        if int(payment_id) == 1:
            try:
                time.sleep(1)
                self.action.click_element(*Locators.CASH_ON_DELIVERY_OPTION)
                print("\n[DONE] -- I chose Cash On Delivery option.")
            except Exception as e:
                print("[ERROR] -- There was an issue with Cash On Delivery option --> " + str(e) + "")
        elif int(payment_id) == 2:
            try:
                self.action.click_element(*Locators.BANK_TRANSFER_OPTION)
                print("[DONE] -- I chose Bank Transfer option.")
            except Exception as e:
                print("[ERROR] -- There was an issue with Bank Transfer option --> " + str(e) + "")
        else:
            print("[ERROR] -- Wrong payment option id was given.")
