import time

from driver import Browser
from pages.actions.actions import Actions
from pages.constants import Locators


class CheckoutPage(Browser):
    # Checkout Page Actions

    def __init__(self):
        self.action = Actions()

    def by_selecting_the_proper_button(self):
        try:
            time.sleep(2)
            self.action.click_element(*Locators.CART_ICON)
            time.sleep(1)
            self.action.click_element(*Locators.GO_TO_CHECKOUT_BUTTON)
            print("\n[DONE] -- Successfully clicked on the cart icon.")
        except Exception as e:
            print("\n[ERROR] -- There was an issue while trying to click on the cart icon --> " + str(e) + "")
