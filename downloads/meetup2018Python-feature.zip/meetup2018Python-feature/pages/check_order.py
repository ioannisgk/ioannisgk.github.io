from driver import Browser
from pages.actions.actions import Actions
from pages.constants import Locators


class CheckOrderPage(Browser):
    # Check Order Page Actions

    def __init__(self):
        self.action = Actions()

    def id(self):
        if self.action.check_element_displayed(Locators.ORDER_ID):
            print("[DONE] -- "+self.action.take_text_of_element(Locators.ORDER_ID)+"")
            print("\n")
        else:
            print("[ERROR] -- I can't see the order id.")
