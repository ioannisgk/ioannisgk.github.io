from driver import Browser
from pages.actions.actions import Actions
from pages.constants import Locators


class HomePage(Browser):
    # Home Page Actions

    def __init__(self):
        self.action = Actions()

    def search(self, search_term):
        # this method is responsible for searching through search bar given the "search_term" query
        # self.click_element(*HomePageLocator.SEARCH_BUTTON)
        # print("\nI found the search button xpath !\n")
        self.action.fill_and_press_enter(search_term, *Locators.SEARCH_FIELD)
        print("I found the search field id !")
        # self.click_element(*HomePageLocator.SUBMIT_BUTTON)
        # print("\nI found the submit button xpath !\n")

    def click_on_login_button(self):
        self.action.click_element(*Locators.SIGN_IN_BUTTON)

    def and_will_check_that_is_the_proper_one(self, website):
        self.action.navigate(website)
        global result
        if self.action.get_page_title() == "Bazinga":
            assert True, "Page title is Bazinga."
            self.click_on_login_button()
            result = "\n[DONE] -- I navigated successfully in the home page of Bazinga and I clicked on Sing In button too.\n"
        else:
            result = "[ERROR] -- I couldn't navigate in the home page :( "
            raise AssertionError("Page title is not Bazinga")
        return result
