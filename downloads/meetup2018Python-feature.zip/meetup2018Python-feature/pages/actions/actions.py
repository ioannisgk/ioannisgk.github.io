from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.select import Select

from driver import Browser


class Actions(Browser):

    def click_element(self, *locator):
        # this method clicks on a given element
        self.driver.find_element(*locator).click()

    def fill(self, text, *locator):
        # this method fill the search bar with a given query
        self.driver.find_element(*locator).send_keys(text)

    def fill_and_press_enter(self, text, *locator):
        # this method fill the search bar with a given query and then press enter

        self.driver.find_element(*locator).send_keys(text, Keys.ENTER)

    def navigate(self, address):
        self.driver.get(address)
        # this method navigates to a given url

        self.driver.get(address)

    def get_page_title(self):
        # this method returns the current title of the web page
        return self.driver.title

    def select_from_menu(self, country_name, country_select_menu_id):
        select_ = Select(self.driver.find_element_by_name(country_select_menu_id))
        select_.select_by_visible_text(country_name)

    def check_element_displayed(self, query):
        given_element = self.driver.find_element(By.XPATH, query)  # this element is visible
        global flag
        if given_element.is_displayed():
            print("\n[DONE] -- I found the element ---------> " + str(given_element) + "")
            flag = True
        else:
            print("\n[ERROR] -- Could not find out the element -------> " + str(given_element) + "")
            flag = False
        return flag

    def take_text_of_element(self, query):
        text = self.driver.find_element(By.XPATH, query).text
        return text
