import time

from driver import Browser
from pages.actions.actions import Actions
from pages.constants import Locators


class ShippingPage(Browser):
    # Shipping Page Actions

    def __init__(self):
        self.action = Actions()

    def information_and_will_choose_a_shipping_method(self, shipping_method):
        try:
            time.sleep(7)
            self.action.click_element(*Locators.CREATE_NEW_ADDRESS_BUTTON)
            print("\n[DONE] -- I pressed '+ New Address' button successfully.")
            self.complete_shipping_form()
            self.choose_shipping_method(shipping_method)
            time.sleep(3)
            self.action.click_element(*Locators.NEXT_BUTTON)
        except Exception as e:
            print("\n[ERROR] -- There was an issue with the '+ New Address button --> " + str(e) + "'")

    def complete_shipping_form(self):
        try:
            time.sleep(2)
            self.action.fill(Locators.STREET_ADDRESS, *Locators.STREET_ADDRESS_INPUT)
            time.sleep(2)
            self.action.fill(Locators.CITY_NAME, *Locators.CITY_NAME_INPUT)
            time.sleep(2)
            self.action.fill(Locators.POSTAL_CODE, *Locators.POSTAL_CODE_INPUT)
            time.sleep(2)
            self.action.select_from_menu(Locators.GREECE, Locators.COUNTRY)
            time.sleep(2)
            self.action.select_from_menu(Locators.KENTRIKI_MAKEDONIA, Locators.REGION)
            time.sleep(2)
            self.action.fill(Locators.TELEPHONE, *Locators.TELEPHONE_INPUT)
            time.sleep(3)
            self.action.click_element(*Locators.SAVE_SHIPPING_FORM_BUTTON)
            time.sleep(3)
            print("[DONE] -- The form completed successfully.")
        except Exception as e:
            print("[ERROR] -- The form was not completed because of --> " + str(e) + "")

    def choose_shipping_method(self, shipping_method_id):

        # print("THE SHIPPING ID IS --> "+shipping_method_id+"")
        self.driver.execute_script("window.scrollTo(0, 1000);")

        if int(shipping_method_id) == 1:
            try:
                self.action.click_element(*Locators.UPS_SHIPPING_COMPANY)
                print("[DONE] -- You selected UPS shipping method.")
            except Exception as e:
                print("[ERROR] -- Issue with UPS shipping method --> "+str(e)+"")
        elif int(shipping_method_id) == 2:
            try:
                self.action.click_element(*Locators.ELTA_SHIPPING_COMPANY)
                print("[DONE] -- You selected ELTA shipping method.")
            except Exception as e:
                print("[ERROR] -- Issue with ELTA shipping method --> "+str(e)+"")
        elif int(shipping_method_id) == 3:
            try:
                self.action.click_element(*Locators.FREE_SHIPPING_OPTION)
                print("[DONE] -- You selected free shipping method.")
            except Exception as e:
                print("[ERROR] -- Issue with free shipping method --> "+str(e)+"")
        else:
            print("[ERROR] -- Wrong shipping method id was given.")

