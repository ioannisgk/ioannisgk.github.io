import time

from pages.home import *


class LoginPage(Browser):
    # Login Page Actions
    def __init__(self):
        self.action = Actions()

    def and_will_try_go_login(self):
        self.complete_login_form()

    def complete_login_form(self):
        # Email / Username input section
        try:
            time.sleep(4)
            self.action.fill(Locators.GIVEN_EMAIL, *Locators.USERNAME_INPUT)
            print("\n[DONE] -- I inserted the email successfully in the username input field.")
        except Exception as e:
            print("[ERROR] -- The issue with the username input was --> "+str(e)+"")

        # Password input section
        try:
            self.action.fill_and_press_enter(Locators.PASSWORD, *Locators.PASSWORD_INPUT)
            print("[DONE] -- I inserted the password successfully in the password input field and I pressed ENTER.")
        except Exception as e:
            print("[ERROR] -- The issue with the password input was --> "+str(e)+"")
