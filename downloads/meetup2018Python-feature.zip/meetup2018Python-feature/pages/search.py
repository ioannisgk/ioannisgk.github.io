from driver import Browser
from pages.actions.actions import Actions
from pages.constants import Locators


class SearchResultsPage(Browser):
    # Search Results Page Actions

    def __init__(self):
        self.action = Actions()

    def get_element(self, *locator):
        return self.driver.find_element(*locator)

    def get_page_title(self):
        return self.driver.title

    def for_this_category(self, category):
        try:
            self.action.fill_and_press_enter(category, *Locators.SEARCH_FIELD)
            print("\n[DONE] -- I successfully searched for the following category --> "+category+"")
        except Exception as e:
            print("[ERROR] -- There was an issue with the searching function, which was --> "+str(e)+"")
