from driver import Browser
from pages.actions.actions import Actions
from pages.check_order import CheckOrderPage
from pages.checkout import CheckoutPage
from pages.home import HomePage
from pages.login import LoginPage
from pages.payment import PaymentPage
from pages.result import ResultsPage
from pages.search import SearchResultsPage
from pages.shipping import ShippingPage


def before_all(context):
    context.browser         = Browser()
    context.home_page       = HomePage()
    context.search          = SearchResultsPage()
    context.login_page      = LoginPage()
    context.action          = Actions()
    context.see_the_results = ResultsPage()
    context.checkout        = CheckoutPage()
    context.shipping        = ShippingPage()
    context.payment         = PaymentPage()
    context.check_order     = CheckOrderPage()


def after_all(context):
    context.browser.close()
