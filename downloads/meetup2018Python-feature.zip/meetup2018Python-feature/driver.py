from selenium import webdriver


class Browser(object):
    print("\n[BUILD] -- Driver built complete.\n")
    driver = webdriver.Chrome("C:\\Users\\Jim-Comquent\\PycharmProjects\\bdd\\drivers\\chromedriver.exe")
    driver.implicitly_wait(30)
    driver.set_page_load_timeout(30)
    driver.maximize_window()

    def close(self):
        print("\n[FINISHED] -- TEST EXECUTED SUCCESSFULLY.")
        self.driver.close()
