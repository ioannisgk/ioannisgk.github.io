from behave import given, when, then


@given('I am on the "{website}"')
def i_am_on_the_website_using_browser(user_will_go_to_the, website):
    user_will_go_to_the.home_page.and_will_check_that_is_the_proper_one(website)


@then("I should try to login")
def i_should_try_to_login(user_is_in_the):
    user_is_in_the.login_page.and_will_try_go_login()


@when('I will try to search for "{category}"')
def i_will_try_to_search_for_a_category(then_user_will, category):
    then_user_will.search.for_this_category(category)


@then("I will add it to the basket")
def i_will_add_the_product_to_the_basket(after_the_user_will):
    after_the_user_will.see_the_results.he_will_choose_a_product_and_then_will_add_it_into_the_basket()


@then("I should go to checkout section")
def i_should_go_to_checkout_section(then_user_will_go_to):
    then_user_will_go_to.checkout.by_selecting_the_proper_button()


@then('I will try to choose the best {shipping_method}')
def i_will_try_to_choose_the_best_shipping_method(the_user_will_add_his, shipping_method):
    the_user_will_add_his.shipping.information_and_will_choose_a_shipping_method(shipping_method)


@then('I will try to choose a {payment_method}')
def i_will_try_to_choose_a_payment_method(after_the_user_will_choose_a, payment_method):
    after_the_user_will_choose_a.payment.option(payment_method)


@when("I will finish the payment transaction the order id should be displayed")
def i_will_finish_the_payment_transaction_and_the_order_id_should_be_displayed(finally_the_user_will):
    finally_the_user_will.check_order.id()
