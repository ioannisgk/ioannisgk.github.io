import time

from driver import Browser
from pages.actions.actions import Actions
from pages.constants import Locators


class PaymentPage(Browser):
    # Payment Page Actions

    def __init__(self):
        self.action = Actions()

    def option(self, payment_option_id):
        time.sleep(3)
        self.choose_a_payment_option(payment_option_id)
        time.sleep(2)
        self.driver.execute_script("window.scrollTo(0, 400);")
        time.sleep(4)
        self.action.click_element(*Locators.PLACE_ORDER_BUTTON)
        time.sleep(7)

    def choose_a_payment_option(self, payment_id):

        # print("THE PAYMENT ID IS ------>  "+payment_id+"")

        if payment_id == "1":
            try:
                time.sleep(6)
                self.action.click_element(*Locators.CASH_ON_DELIVERY_OPTION)
                print("\n[DONE] -- I chose " + payment_id + " which is Cash On Delivery option.")
            except Exception as e:
                print("\n[ERROR] -- There was an issue with Cash On Delivery option --> " + str(e) + "")
                raise AssertionError("[ERROR] -- I can not click on the Cash on Delivery option because of the "
                                     "payment.choose_a_payment_option function")
        elif payment_id == "2":
            try:
                time.sleep(6)
                self.action.click_element(*Locators.BANK_TRANSFER_OPTION)
                print("\n[DONE] -- I chose " + payment_id + " which is Bank Transfer option.")
            except Exception as e:
                print("\n[ERROR] -- There was an issue with Bank Transfer option --> " + str(e) + "")
                raise AssertionError("[ERROR] -- I can not click on the Bank Transfer option because of the "
                                     "payment.choose_a_payment_option function")
        else:
            print("\n[ERROR] -- You gave wrong payment option.")
            raise AssertionError("[ERROR] -- Wrong payment method was given in the payment.choose_a_payment_option "
                                 "function")


