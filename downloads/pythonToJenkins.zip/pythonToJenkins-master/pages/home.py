
from driver import Browser
from pages.actions.actions import Actions
from pages.constants import Locators


class HomePage(Browser):
    # Home Page Actions

    def __init__(self):
        self.action = Actions()

    def click_on_login_button(self):
        self.action.click_element(*Locators.SIGN_IN_BUTTON)

    def and_will_check_that_is_the_proper_one(self, website):
        self.action.navigate(website)
        if self.action.get_page_title() == "Bazinga":
            self.click_on_login_button()
            print("[DONE] -- I navigated successfully.")
        else:
            raise AssertionError("Page title is not Bazinga in home.and_will_check_that_is_the_proper_one function")


'''
#def search(self, search_term):
        # this method is responsible for searching through search bar given the "search_term" query

    #    self.action.fill_and_press_enter(search_term, *Locators.SEARCH_FIELD)
    #   print("I found the search field id !")
'''
