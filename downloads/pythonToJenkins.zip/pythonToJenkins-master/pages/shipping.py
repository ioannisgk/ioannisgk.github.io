import time

from driver import Browser
from pages.actions.actions import Actions
from pages.constants import Locators


class ShippingPage(Browser):
    # Shipping Page Actions

    def __init__(self):
        self.action = Actions()

    def information_and_will_choose_a_shipping_method(self, shipping_method):

        try:
            time.sleep(7)
            if self.action.check_element_displayed(Locators.IDENTIFICATION_ELEMENT_FOR_NEW_CUSTOMER):
                time.sleep(1)
                self.complete_shipping_form()
                time.sleep(2)
                self.choose_shipping_method(shipping_method)
                time.sleep(3)
                self.action.click_element(*Locators.NEXT_BUTTON)
            else:
                self.action.click_element(*Locators.CREATE_NEW_ADDRESS_BUTTON)
                print("\n[INFO] -- I pressed '+ New Address' button successfully.")
                self.complete_shipping_form()
                self.action.click_element(*Locators.SAVE_SHIPPING_METHOD_PREFERENCE)
                time.sleep(2)
                self.action.click_element(*Locators.SAVE_SHIPPING_FORM_BUTTON)
                time.sleep(3)
                self.choose_shipping_method(shipping_method)
                time.sleep(3)
                self.action.click_element(*Locators.NEXT_BUTTON)
        except Exception as e:
            print("The trace is --> " + str(e))
            raise AssertionError(
                "[ERROR] -- I can not finish the 'choose shipping method' process because of "
                "shipping.information_and_will_choose_a_shipping_method function.")

    def complete_shipping_form(self):
        try:
            time.sleep(2)
            self.action.fill(Locators.STREET_ADDRESS, *Locators.STREET_ADDRESS_INPUT)
            time.sleep(2)
            self.action.fill(Locators.CITY_NAME, *Locators.CITY_NAME_INPUT)
            time.sleep(2)
            self.action.fill(Locators.POSTAL_CODE, *Locators.POSTAL_CODE_INPUT)
            time.sleep(2)
            self.action.select_from_menu(Locators.GREECE, Locators.COUNTRY)
            time.sleep(2)
            self.action.select_from_menu(Locators.KENTRIKI_MAKEDONIA, Locators.REGION)
            time.sleep(2)
            self.action.fill(Locators.TELEPHONE, *Locators.TELEPHONE_INPUT)
            time.sleep(2)
            print("[INFO] -- The form completed successfully.")
        except Exception as e:
            print("[ERROR] -- The form was not completed because of --> " + str(e) + "")
            raise AssertionError(
                "[ERROR] -- I can not complete the shipping form because of shipping.complete_shipping_form function.")

    def choose_shipping_method(self, shipping_method_id):

        # print("THE SHIPPING ID IS --> "+shipping_method_id+"")
        self.driver.execute_script("window.scrollTo(0, 1000);")

        if int(shipping_method_id) == 1:
            try:
                self.action.click_element(*Locators.UPS_SHIPPING_COMPANY)
                print("[DONE] -- I chose UPS shipping method.")
            except Exception as e:
                print("[ERROR] -- Issue with UPS shipping method --> " + str(e) + "")
                raise AssertionError(
                    "[ERROR] -- I can not choose UPS Shipping because of shipping.choose_shipping_method[UPS] function.")
        elif int(shipping_method_id) == 2:
            try:
                self.action.click_element(*Locators.ELTA_SHIPPING_COMPANY)
                print("[DONE] -- I chose ELTA shipping method.")
            except Exception as e:
                print("[ERROR] -- Issue with ELTA shipping method --> " + str(e) + "")
                raise AssertionError(
                    "[ERROR] -- I can not choose ELTA Shipping because of shipping.choose_shipping_method[ES] function.")
        elif int(shipping_method_id) == 3:
            try:
                self.action.click_element(*Locators.FREE_SHIPPING_OPTION)
                print("[DONE] -- I chose free shipping method.")
            except Exception as e:
                print("[ERROR] -- Issue with free shipping method --> " + str(e) + "")
                raise AssertionError(
                    "[ERROR] -- I can not choose Free Shipping because of shipping.choose_shipping_method[FS] function.")
        else:
            print("[ERROR] -- Wrong shipping method id was given.")
            raise AssertionError(
                "[ERROR] -- Wrong shipping method id was given in the shipping.choose_shipping_method function.")
