import time

from driver import Browser
from pages.actions.actions import Actions
from pages.constants import Locators


class CheckOrderPage(Browser):
    # Check Order Page Actions

    def __init__(self):
        self.action = Actions()

    def id(self):
        if self.action.check_element_displayed(Locators.ORDER_ID):
            print("\n[DONE] -- "+self.action.take_text_of_element(Locators.ORDER_ID)+"")
            time.sleep(3)

            try:
                self.action.click_element(*Locators.DROP_DOWN_TO_LOGOUT_MENU)
                print("[INFO] -- Drop-down menu just found.")
            except RuntimeError as e:
                raise AssertionError("[ERROR] -- I can press the drop-down menu to logout because of the "
                                     "check_order.id function")
            time.sleep(2)

            try:
                self.action.click_element(*Locators.LOGOUT_BUTTON)
                print("[DONE] -- I just logged out.")
                print("\n")
                print("=========== END OF EXAMPLE ===========")
                print("\n")
            except RuntimeError as e:
                raise AssertionError("[ERROR] -- I can not click on the logout button because of the check_order.id "
                                     "function")

        else:
            print("[ERROR] -- I can't see the order id.")
            raise AssertionError("[ERROR] -- The function check_order.id just crushed.")
