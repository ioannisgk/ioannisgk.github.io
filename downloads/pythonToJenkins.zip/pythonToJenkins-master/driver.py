from selenium import webdriver
from selenium.webdriver.chrome.options import Options

class Browser(object):
    try:
	
		options = Options()
		options.add_argument('--headless')
		options.add_argument('--no-sandbox')
		options.add_argument('--start-maximized')
		options.add_argument('--disable-extensions')
		options.add_argument('--disable-dev-shm-usage')
		driver = webdriver.Chrome("/usr/local/bin/chromedriver", chrome_options=options)
	
        driver.implicitly_wait(30)
        driver.set_page_load_timeout(30)
        driver.maximize_window()
        print("[BUILD] Driver created successfully.")
    except RuntimeError as e:
        raise AssertionError("[ERROR] -- Driver can not be created.")

    def close(self):
        print("\n[FINISHED] -- TEST CASE EXECUTED.")
        self.driver.close()
        self.driver.quit()
