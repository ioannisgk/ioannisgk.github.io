
function validatePassword(){
    var password = document.getElementById("password");
    var password2 = document.getElementById("password2");
    if(password.value != password2.value) {
        password.value = "";
        password2.value = "";
        alert("Οι κωδικοί πρέπει να είναι ίδιοι");
        return false;
    } else if(password.value.length<8){
        password.value = "";
        password2.value = "";
        alert("Ο κωδικός πρέπει να είναι τουλάχιστον 8 χαρακτήρες");
        return false;
    }else {
        return true;
  }
}
	
