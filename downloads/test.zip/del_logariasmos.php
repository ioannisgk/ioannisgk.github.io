<?php
    // Σύνδεση στην βάση δεδομένων
    include 'connect_db.php'; 
    
    // Παίρνουμε τα δεδομένα από τη φόρμα
    $logariasmos = $_POST['logariasmos'];
  
    $query = "DELETE FROM Logariasmos WHERE id=".$logariasmos;
    
    $result = mysqli_query($con,$query);
    if(!$result){
        mysqli_close($con);
        echo '<html><meta charset="UTF-8"><script>alert("Σφάλμα κατά τη διαγραφή."); document.location="main.php";</script></html>';
    } else{
        mysqli_close($con);
        echo '<html><meta charset="UTF-8"><script>alert("Επιτυχής διαγραφή λογαριασμού."); document.location="main.php";</script></html>';
    }

?>
