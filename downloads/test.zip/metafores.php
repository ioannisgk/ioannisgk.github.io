<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
        <link href="styles.css" rel="stylesheet">
        
        <title> My Bank - Αρχική </title>
    </head>
    <body>

        <div class="container-fluid">
            <div class = "row">
                <?php include("header.html");?>
            </div>
            
            <div class = "row" >
                <?php
                    // Εισαγωγή του μενού
                    include('menu.html');
                ?>
            </div>
            <hr>
            
            <div class="row" style="margin-left:2%">


                <div class = "col-xs-12 col-sm-8 col-md-8 col-lg-8 ">
                    
                         <div class="row" style="margin-right:15%">
                        <h4 >Μεταφορά χρημάτων</h4>
                        <div class="class1">
                        <div class="row">

                                <div class = "col-xs-12 col-sm-12 col-md-12 col-lg-12 ">
                                    <form method="POST" action="metafora_new.php">
                                        <table style="margin: 5px; padding:15px">
                                            <tr> 
                                                <td style="text-align: right"> Από λογαριασμό <span style="color:red">* </span></td>
                                                
                                                <td> 
                                                    <select name="logariasmos">
                                                        <?php
                                                        session_start();
                                                        include "connect_db.php";
                                                        $query = "SELECT * FROM Logariasmos WHERE id_pelati=".$_SESSION['user_id'];
                                    
                                                        $result = mysqli_query($con,$query);
                                                        $k = 0;
                                                        while ($row = mysqli_fetch_array($result)) {
                                                            $k++;
                                                            echo "<option value='".$row[0]."'>Λογαριασμός ".$k." (".$row[4]." Ευρώ)</option>";
                                                        }
                                                        ?>
                                                        
                                                    </select>
                                                </td>
                                            </tr>
                                            
                                            <tr> 
                                                <td style="text-align: right"> Προς λογαριασμό <span style="color:red">* </span></td>
                                                
                                                <td> 
                                                    <input type="text" name="iban" placeholder="Εισάγετε το ΙΒΑΝ">
                                                </td>
                                            </tr>
                                            
                                            <tr> 
                                                <td style="text-align: right"> Ποσό <span style="color:red">* </span></td>
                                                
                                                <td> 
                                                    <input type="text" name="poso" placeholder="Σε μορφή ΧΧ,ΥΥ Ευρώ">
                                                </td>
                                            </tr>
                                                                                        <tr> 
                                                <td style="text-align: right"> Πληροφορίες για το δικαιούχο  </span></td>
                                                
                                                <td> 
                                                    <textarea name="plirofories"> </textarea>
                                                </td>
                                            </tr>
                                            
                                            </tr>
                                           <tr> 
                                                <td style="text-align: right"> Να εκτελεστεί  </span></td>
                                                
                                                <td> 
                                                    <input type="radio" name="radio1" value="now" checked> Άμεσα
                                                    <input type="radio" name="radio1"> Στις <input type="date" name="date">
                                                    
                                                </td>
                                            </tr>
                                            
                                            <tr> 
                                                <td style="text-align: right"> Εμφάνιση στις πρόσφατες συναλλαγές;  </span></td>
                                                
                                                <td> 
                                                    <input type="checkbox" > 
                                                    
                                                    
                                                </td>
                                            </tr>
                                            
                                        </table>
                                        
                                        <br>
                                    <div align="center">
                                   <input type="submit" class="btn btn-primary" value="ΥΠΟΒΟΛΗ"
                                          style="width: 30%;  ">
                                    </div>
                                    </form>
                                

                                </div>
                               
                                
                        </div>
                    </div>                  
                </div>

                
            </div>
            

        </div>
        <div class = "row" style="margin-top: 2%">
                <?php include("footer.html");?>
            </div>
    </body>
</html>
