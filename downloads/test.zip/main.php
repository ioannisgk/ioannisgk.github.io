<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
        <link href="styles.css" rel="stylesheet">
        
        <title> My Bank - Αρχική </title>
    </head>
    <body>

        <div class="container-fluid">
            <div class = "row">
                <?php include("header.html");?>
            </div>
            
            <div class = "row" >
                <?php
                    // Εισαγωγή του μενού
                    include('menu.html');
                ?>
            </div>
            <hr>
            <form method="POST" action="del_user.php">
                <div style="text-align: right">
                <input type="submit" class="btn btn-danger" value="ΔΙΑΓΡΑΦΗ ΧΡΗΣΤΗ"
                                          style="width: 30%;  ">
                </div>                    
            </form>
            <div class="row" style="margin-left:2%">
                <div class = "col-xs-12 col-sm-8 col-md-8 col-lg-8 " >
                    <div class="row" style="margin-right:15%">
                        <h4 >Οι λογαριασμοί μου</h4>
                        
                        <a href="logariasmos_new.php"> Δημιουργία νέου λογαριασμού</a>
                        <a href="logariasmos_delete.php"> Διαγραφή λογαριασμού</a>
                        <div class="class1">

                                <?php
                                    session_start();
                                    include "connect_db.php";
                                    $query = "SELECT * FROM Logariasmos WHERE id_pelati=".$_SESSION['user_id'];
                                    
                                    $result = mysqli_query($con,$query); 
                                    if ($result and mysqli_num_rows($result) > 0) {
                                        $k = 0;
                                        while ($row = mysqli_fetch_array($result)) {
                                            $k++;
                                            echo '<div class="row">';
                                            echo '<div class = "col-xs-12 col-sm-6 col-md-6 col-lg-6 ">';
                                            
                                        
                                            echo "<div style='color:blue'> Λογαριασμός ".$k."</div>";
                                            echo "IBAN:".$row[2]."<br>";
                                            echo "Ημερομηνία δημιουργίας:".date('d-m-Y', strtotime($row[3]))."<br>";
                                            echo "</div>";
                                            echo '<div class = "col-xs-12 col-sm-6 col-md-6 col-lg-6 ">';
                                            echo "Διαθέσιμο υπόλοιπο:".$row[4]."<br>";

                                            echo "</div>";
                                            echo "</div>";
                                            echo "<hr>";
                                        }
                                    }
                                
                                ?>
                        
                        </div>
                    </div>
                    <br>
                    <div class="row" style="margin-right:15%">
                        <h4>Οι κάρτες μου</h4>
                        <div class="class1">
                        <div class="row">
                                <div class = "col-xs-12 col-sm-6 col-md-6 col-lg-6 ">
                                    <a href="">Όνομα Κάρτας 1</a>
                                    <br>
                                        Αριθμός κάρτας: 1234 5678 1234 5678
                                    <br>
                                    Ημερομηνία λήξης: DD/MM/YYYY
                                </div>
                               
                                <div class = "col-xs-12 col-sm-6 col-md-6 col-lg-6 "
                                     style="text-align:right;" >
                                    Διαθέσιμο Υπόλοιπο: ΧΧ,ΥΥ Ευρώ
                                    <div style="color:green">
                                    Πιστώσεις μήνα: ΧΧ,ΥΥ Ευρώ
                                    </div>
                                    <div style="color:red">
                                    Χρεώσεις μήνα: ΧΧ,ΥΥ Ευρώ
                                    </div>
                                </div>
                            
                            </div>
                        <hr>
                        <div class="row">
                            
                                <div class = "col-xs-12 col-sm-6 col-md-6 col-lg-6 ">
                                    <a href="">Όνομα Κάρτας 2</a>
                                    <br>
                                    Αριθμός κάρτας: 4321 8765 4321 8765 
                                    <br>
                                    Ημερομηνία λήξης: DD/MM/YYYY
                                </div>
                               
                                <div class = "col-xs-12 col-sm-6 col-md-6 col-lg-6 "
                                     style="text-align:right;" >
                                    Διαθέσιμο Υπόλοιπο: ΧΧ,ΥΥ Ευρώ
                                    <div style="color:green">
                                    Πιστώσεις μήνα: ΧΧ,ΥΥ Ευρώ
                                    </div>
                                    <div style="color:red">
                                    Χρεώσεις μήνα: ΧΧ,ΥΥ Ευρώ
                                    </div>
                                </div>
                            </div>
                            </div>
                    </div>
                    
                </div>

                <div class = "col-xs-12 col-sm-4 col-md-4 col-lg-4 ">
                    
                         <div class="row" style="margin-right:15%">
                        <h4 >Πρόσφατες συναλλαγές</h4>
                        <div class="class1">

                                <?php
                                    session_start();
                                    include "connect_db.php";
                                    $query = "SELECT * FROM Metafora, Logariasmos WHERE (Metafora.id_logariasmou1 = Logariasmos.id".
                                            " OR Metafora.id_logariasmou2 = Logariasmos.id)".
                                            " AND Logariasmos.id_pelati = ".$_SESSION['user_id']." ORDER BY Hmerominia DESC";
                                    
                                    $result = mysqli_query($con,$query); 
                                    if ($result and mysqli_num_rows($result) > 0) {
                                        $k = 0;
                                        while ($row = mysqli_fetch_array($result)) {
                                            $k++;
                                            if ($k>2) break;
                                            echo '<div class="row">';
                                            echo '<div class = "col-xs-12 col-sm-12 col-md-12 col-lg-12 ">';
                                            
                                        
                                            echo "<div style='color:blue'> Μεταφορά ".$k."</div>";
                                            echo $row[3]." Ευρώ<br>";
                                            echo "Ημερομηνία εκτέλεσης: ".date('d-m-Y', strtotime($row[4]))."<br>";
                                            echo '<a href="">Λεπτομέρειες ></a>  &nbsp <a href="">Νέα όμοια ></a>';
                                            echo "</div>";
                                            
                                            echo "</div>";
                                            echo "<hr>";
                                        }
                                    } 
                                    $query = "SELECT * FROM Pliromi, Logariasmos WHERE Pliromi.id_logariasmos = Logariasmos.id".
                                            " AND Logariasmos.id_pelati = ".$_SESSION['user_id']." ORDER BY Hmerominia DESC";
                                    
                                    $result = mysqli_query($con,$query); 
                                    if ($result and mysqli_num_rows($result) > 0) {
                                        $k = 0;
                                        while ($row = mysqli_fetch_array($result)) {
                                            $k++;
                                            if ($k>2) break;
                                            echo '<div class="row">';
                                            echo '<div class = "col-xs-12 col-sm-12 col-md-12 col-lg-12 ">';
                                            
                                        
                                            echo "<div style='color:blue'> Πληρωμή ".$k."</div>";
                                            echo $row[3]." Ευρώ<br>";
                                            echo "Ημερομηνία εκτέλεσης: ".date('d-m-Y', strtotime($row[4]))."<br>";
                                            echo '<a href="">Λεπτομέρειες ></a>  &nbsp <a href="">Νέα όμοια ></a>';
                                            echo "</div>";
                                            
                                            echo "</div>";
                                            echo "<hr>";
                                        }
                                    }
                                
                                ?>
                            <div class="row">
                                <div class = "col-xs-12 col-sm-12 col-md-12 col-lg-12 ">
                                    <form method="POST" action="synallages.php">
                                   <button class="btn btn-primary" type="submit" style="width: 95%; ">
                                    ΙΣΤΟΡΙΚΟ ΣΥΝΑΛΛΑΓΩΝ
                                   </button>
                                    </form>

                                </div>
                               
                                
                            </div>
                        </div>
                    </div>                  
                </div>

                
            </div>
            
            <div class = "row" style="margin-top: 2%">
                <?php include("footer.html");?>
            </div>
        </div>
    </body>
</html>
