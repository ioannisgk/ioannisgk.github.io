-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 22, 2019 at 04:48 PM
-- Server version: 5.5.57-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `Bank`
--
CREATE DATABASE IF NOT EXISTS `Bank` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `Bank`;

-- --------------------------------------------------------

--
-- Table structure for table `Logariasmos`
--

CREATE TABLE IF NOT EXISTS `Logariasmos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_pelati` int(11) NOT NULL,
  `IBAN` varchar(30) NOT NULL,
  `Dimiourgia` date DEFAULT NULL,
  `Ypoloipo` real NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_pelati` (`id_pelati`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `Logariasmos`
--

INSERT INTO `Logariasmos` (`id`, `id_pelati`, `IBAN`, `Dimiourgia`, `Ypoloipo`) VALUES
(1, 1, 'GR123456789', '2019-02-22', 1000000);

-- --------------------------------------------------------

--
-- Table structure for table `Metafora`
--

CREATE TABLE IF NOT EXISTS `Metafora` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_logariasmou1` int(11) NOT NULL,
  `id_logariasmou2` int(11) NOT NULL,
  `Poso` decimal(10,0) NOT NULL,
  `Hmerominia` date NOT NULL,
  `Plirofories` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_logariasmou1` (`id_logariasmou1`,`id_logariasmou2`),
  KEY `id_logariasmou2` (`id_logariasmou2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Pelatis`
--

CREATE TABLE IF NOT EXISTS `Pelatis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Onoma` varchar(40) NOT NULL,
  `Eponymo` varchar(40) NOT NULL,
  `Email` varchar(40) DEFAULT NULL,
  `Password` varchar(30) NOT NULL,
  `Birth` datetime DEFAULT NULL,
  `Sex` enum('','M','F') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `Pelatis`
--

INSERT INTO `Pelatis` (`id`, `Onoma`, `Eponymo`, `Email`, `Password`, `Birth`, `Sex`) VALUES
(1, 'Δημήτριος', 'Παπαδόπουλος', 'dimpap@gmail.com', '1234', '1989-02-15', 'M');

-- --------------------------------------------------------

--
-- Table structure for table `Pliromi`
--

CREATE TABLE IF NOT EXISTS `Pliromi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Typos` enum('Εφορία','ΕΝΦΙΑ','ΔΕΗ','Ασφάλεια') NOT NULL,
  `kodikos` varchar(10) NOT NULL,
  `Poso` real NOT NULL,
  `Hmerominia` datetime NOT NULL,
  `id_logariasmos` int(11) NOT NULL,
  `id_syndromiti` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_logariasmos1` (`id_logariasmos`,`id_syndromiti`),
  KEY `id_syndromiti` (`id_syndromiti`),
  KEY `id_logariasmos` (`id_logariasmos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Logariasmos`
--
ALTER TABLE `Logariasmos`
  ADD CONSTRAINT `Logariasmos_ibfk_1` FOREIGN KEY (`id_pelati`) REFERENCES `Pelatis` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Metafora`
--
ALTER TABLE `Metafora`
  ADD CONSTRAINT `Metafora_ibfk_2` FOREIGN KEY (`id_logariasmou2`) REFERENCES `Logariasmos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Metafora_ibfk_1` FOREIGN KEY (`id_logariasmou1`) REFERENCES `Logariasmos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Pliromi`
--
ALTER TABLE `Pliromi`
  ADD CONSTRAINT `Pliromi_ibfk_2` FOREIGN KEY (`id_syndromiti`) REFERENCES `Pelatis` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Pliromi_ibfk_1` FOREIGN KEY (`id_logariasmos`) REFERENCES `Logariasmos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
