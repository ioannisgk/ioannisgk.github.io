<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
        <link href="styles.css" rel="stylesheet">
        <script src="functions.js"></script>
        <title> Εγγραφή νέου χρήστη </title>
    </head>
    <body>
        <div class="container-fluid">
            <div class = "row">
                <?php include("header.html");?>
            </div>
            
            <div class = "row" >
                <?php
                    // Εισαγωγή του μενού
                    include('menu.html');
                ?>
            </div>

            <hr>
            
            <div class = "row" >

                <div class = "col-xs-12 col-sm-6 col-md-6 col-lg-6" style="left:20%">
                        <h2 style="text-align: center">Εγγραφή νέου χρήστη</h2>
                        <div class="style1" style="text-align: center;">
                            <br>
                            <form  method="POST" action="register_user.php" onsubmit="return validatePassword()" >
                                
                                <label class="style2"> Όνομα:</label>
                                <input type="text" name="onoma" class="form-control control1"  placeholder="Όνομα" 
                                       required autofocus>
                                <br><br>
                                
                                <label class="style2"> Επώνυμο:</label>
                                <input type="text" name="eponimo" class="form-control control1"  
                                       placeholder="Επώνυμο" required>
                                <br><br>
                                
                                <label class="style2"> email:</label>
                                <input type="email" name="email" class="form-control control1" 
                                       placeholder="Διεύθυνση email"
                                        required>
                                <br><br>
                                
                                <label class="style2"> Κωδικός:</label>
                                <input type="password" id="password" name="password" class="form-control control1"  
                                       placeholder="Κωδικός χρήστη" 
                                       required >
                                <br><br>
                                    
                                <label class="style2"> Επανάληψη κωδικού:</label>
                                <input type="password" id="password2" name="password2" class="form-control control1"  
                                       placeholder="Επιβεβαίωση κωδικού" 
                                       required>
                                <br><br>
                                
                                <label class="style2"> Φύλο:</label>
                                <select id="sex" name="sex" class="form-control control1" >
                                    <option selected> Δώσε φύλο </option>
                                    <option> Άντρας</option>
                                    <option> Γυναίκα</option>
                                </select>
                                <br><br>
                                
                                <label class="style2"> Ημερομηνία γέννησης:</label>
                                <input type="date" name="birth" class="form-control control1">
                                <br><br>
                                <div align="center">
                                <button class="btn btn-danger" type="reset" style="width: 20%;margin-left: 18%">Καθαρισμός</button>    
                                <button class="btn btn-primary" type="submit" style="width: 20%;margin-left: 8%">Εγγραφή</button>
                                </div>
                            </form>
                        <br>
                        </div>
                </div>
                <div class = "col-xs-12 col-sm-3 col-md-3 col-lg-3 " style="left:20%">
                    <a href="index.php" class="btn" style="color:blue;"> Επιστροφή </a>
                </div>

            </div>
            <div class = "row" style="margin-top: 2%">
                    <?php include("footer.html");?>
            </div>
        </div>
    </body>
</html>
