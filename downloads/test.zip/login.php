   
<?php
    session_start();
    // Σύνδεση στην βάση δεδομένων
    include 'connect_db.php'; 
    
    // Get data from the form
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    // Αναζήτηση εγγραφής πελάτη στην βάση
    $query = "SELECT * FROM Pelatis WHERE email = '$email'";
    $result = mysqli_query($con,$query);
    
    // Έλεγχος αν υπάρχει το email
    $num=mysqli_num_rows($result);
    // Αν δεν υπάρχει ο χρήστης τότε εμφανίζει μήνυμα και ανακατευθύνει
    // στην αρχική σελίδα
    if ($num == 0){
        mysqli_close($con);
            
	echo '<html><meta charset="UTF-8"><script>alert("Ο χρήστης δεν βρέθηκε!"); document.location="index.php";</script></html>';
    } else {
        // Λήψη στοιχείων χρήστη
        $user = mysqli_fetch_row($result);
        $user_id = $user[0];
	$user_fname = $user[1];
        $user_lname = $user[2];
        $user_email = $user[3];
	$user_password = $user[4];
	$user_sex = $user[5];
        $user_birth = $user[6];
	

        // Έλεγχος password
	if($password != $user_password){
            mysqli_close($con);
            echo '<html><meta charset="UTF-8"><script>alert("Λάθος κωδικός!"); document.location="index.php";</script></html>';
	} else{
            $_SESSION['user_email'] = $user_email;
            $_SESSION['user_lname'] = $user_lname;
            $_SESSION['user_fname'] = $user_fname;
            $_SESSION['user_id'] = $user_id;
            mysqli_close($con);
            // Ανάλογα με το ρόλο έχουμε την κατάλληλη σύνδεση
            header("Location: main.php");
            
        }
    }
    
    
?>