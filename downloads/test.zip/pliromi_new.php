<?php
    // Σύνδεση στην βάση δεδομένων
    include 'connect_db.php'; 
    session_start();
    // Παίρνουμε τα δεδομένα από τη φόρμα
    $logariasmos = $_POST['logariasmos'];
    $type = $_POST['type'];
    $code = $_POST['code'];
    $poso = $_POST['poso'];
    $date = $_POST['date'];
    $user_id = $_SESSION['user_id'];
    
    // Ελέγχουμε αν υπάρχουν αρκετά χρήματα στο λογαριασμό
    $query = "SELECT Ypoloipo FROM Logariasmos WHERE id=".$logariasmos;
    $result = mysqli_query($con,$query);
    $row = mysqli_fetch_array($result);
    $ypoloipo = $row[0];
    if($ypoloipo < $poso){
        mysqli_close($con);

        echo '<html><meta charset="UTF-8"><script>alert("Δεν υπάρχει αρκετά μεγάλο ποσό."); document.location="pliromes.php";</script></html>';
    } else {
        $query = "INSERT INTO Pliromi(Typos, kodikos, Poso, Hmerominia, id_logariasmos, id_syndromiti) VALUES ('$type', '$code', $poso, '$date', $logariasmos, $user_id )";
        $result = mysqli_query($con,$query);

        if(!$result){
            mysqli_close($con);
            echo '<html><meta charset="UTF-8"><script>alert("Σφάλμα κατά την καταχώρηση πληρωμής."); document.location="pliromes.php";</script></html>';
        } else{
             // Μεταβολές των ποσών
            $query = "UPDATE Logariasmos SET Ypoloipo=".$ypoloipo."-".$poso." WHERE id=".$logariasmos;
            mysqli_query($con, $query);
            mysqli_close($con);
            echo '<html><meta charset="UTF-8"><script>alert("Επιτυχής καταχώρηση πληρωμής."); document.location="main.php";</script></html>';
        }
    
    }
?>
