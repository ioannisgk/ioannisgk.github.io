<?php
    // Σύνδεση στην βάση δεδομένων
    include 'connect_db.php'; 
    
    // Παίρνουμε τα δεδομένα από τη φόρμα
    $onoma = $_POST['onoma'];
    $eponimo = $_POST['eponimo'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $sex = $_POST['sex'];
    $birthday = $_POST['birth'];
    
    // Αναζήτηση εγγραφής πελάτη στην βάση
    $query = "SELECT * FROM Pelatis WHERE Email = '$email'";
    $result = mysqli_query($con,$query)
        or die("Λάθος κατά την εκτέλεση του ερωτήματος");

    // Έλεγχος αν υπάρχει το email
    $num=mysqli_num_rows($result);
    // Αν δεν υπάρχει ο χρήστης τότε εμφανίζει μήνυμα και ανακατευθύνει
    // στην αρχική σελίδα
    if ($num > 0){
        mysqli_close($con);
        echo '<html><meta charset="UTF-8"><script>alert("Υπάρχει ήδη χρήστης με email:'.$email.'"); document.location="register.php";</script></html>';
    } else {
        if($sex =='' && $birthday == ''){
            $query = "INSERT INTO Pelatis(Onoma, Eponymo, Email, Password) VALUES ('$onoma', '$eponimo', '$email', '$password')";
        }else if($birthday == ''){
            if ($sex=='Άντρας')
                $sex = 'M';
            else 
                $sex = 'F';
            $query = "INSERT INTO Pelatis(Onoma, Eponymo, Email, Password, Sex) VALUES ('$onoma', '$eponimo', '$email', '$password', '$sex')";
        }else if($sex == ''){
            $query = "INSERT INTO Pelatis(Onoma, Eponymo, Email, Password, Birth) VALUES ('$onoma', '$eponimo', '$email', '$password', '$birthday')";
        } else {
            if ($sex=='Άντρας')
                $sex = 'M';
            else 
                $sex = 'F';
            $query = "INSERT INTO Pelatis(Onoma, Eponymo, Email, Password, Sex, Birth) VALUES ('$onoma', '$eponimo', '$email', '$password', '$sex', '$birthday')";
            
        }
        $result = mysqli_query($con,$query);
        if(!$result){
            mysqli_close($con);
            echo '<html><meta charset="UTF-8"><script>alert("Σφάλμα κατά την αποθήκευση."); document.location="register.php";</script></html>';
        } else{
            mysqli_close($con);
            echo '<html><meta charset="UTF-8"><script>alert("Επιτυχής αποθήκευση χρήστη."); document.location="index.php";</script></html>';
        }
    }
    
    
?>
