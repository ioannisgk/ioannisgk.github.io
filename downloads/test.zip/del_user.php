<?php
    // Σύνδεση στην βάση δεδομένων
    include 'connect_db.php'; 
    session_start();
    $user_id = $_SESSION['user_id'];
  
    $query = "DELETE FROM Pelatis WHERE id=".$user_id;
    
    $result = mysqli_query($con,$query);
    if(!$result){
        mysqli_close($con);
        echo '<html><meta charset="UTF-8"><script>alert("Σφάλμα κατά τη διαγραφή."); document.location="main.php";</script></html>';
    } else{
        mysqli_close($con);
        echo '<html><meta charset="UTF-8"><script>alert("Επιτυχής διαγραφή λογαριασμού χρήστη."); document.location="index.php";</script></html>';
    }

?>
