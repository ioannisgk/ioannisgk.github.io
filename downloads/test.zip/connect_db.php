<?php
    $server = 'localhost';
    $username = 'xesternos';
    $password = '';
    $dbname = 'xesternos';

    // Σύνδεση με MySQL
    $con = mysqli_connect($server,$username, $password)
            or die("Σφάλμα κατά τη σύνδεση με τη ΒΔ");   
    mysqli_set_charset($con, "utf8");

    // Επιλογή Βάσης Δεδομένων
    mysqli_select_db($con,$dbname)
        or die("Δεν ήταν δυνατή η επιλογή της ΒΔ.");
?>
