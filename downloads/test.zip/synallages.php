<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
        <link href="styles.css" rel="stylesheet">
        
        <title> My Bank - Συναλλαγές </title>
    </head>
    <body>

        <div class="container-fluid">
            <div class = "row">
                <?php include("header.html");?>
            </div>
            
            <div class = "row" >
                <?php
                    // Εισαγωγή του μενού
                    include('menu.html');
                ?>
            </div>
            <hr>
            
            <div class="row" style="margin-left:2%">


                <div class = "col-xs-12 col-sm-8 col-md-8 col-lg-8 ">
                    
                         <div class="row" style="margin-right:15%">
                        <h4 >Συναλλαγές</h4>
                        <div class="class1">
                        <?php
                                    session_start();
                                    include "connect_db.php";
                                    $query = "SELECT * FROM Metafora, Logariasmos WHERE (Metafora.id_logariasmou1 = Logariasmos.id".
                                            " OR Metafora.id_logariasmou2 = Logariasmos.id)".
                                            " AND Logariasmos.id_pelati = ".$_SESSION['user_id']." ORDER BY Hmerominia DESC";
                                    
                                    $result = mysqli_query($con,$query); 
                                    if ($result and mysqli_num_rows($result) > 0) {
                                        $k = 0;
                                        while ($row = mysqli_fetch_array($result)) {
                                            $k++;

                                            echo '<div class="row">';
                                            echo '<div class = "col-xs-12 col-sm-12 col-md-12 col-lg-12 ">';
                                            
                                        
                                            echo "<div style='color:blue'> Μεταφορά ".$k."</div>";
                                            echo $row[3]." Ευρώ<br>";
                                            echo "Ημερομηνία εκτέλεσης: ".date('d-m-Y', strtotime($row[4]))."<br>";
                                            echo '<a href="">Λεπτομέρειες ></a>  &nbsp <a href="">Νέα όμοια ></a>';
                                            echo "</div>";
                                            
                                            echo "</div>";
                                            echo "<hr>";
                                        }
                                    } 
                                    $query = "SELECT * FROM Pliromi, Logariasmos WHERE Pliromi.id_logariasmos = Logariasmos.id".
                                            " AND Logariasmos.id_pelati = ".$_SESSION['user_id']." ORDER BY Hmerominia DESC";
                                    
                                    $result = mysqli_query($con,$query); 
                                    if ($result and mysqli_num_rows($result) > 0) {
                                        $k = 0;
                                        while ($row = mysqli_fetch_array($result)) {
                                            $k++;

                                            echo '<div class="row">';
                                            echo '<div class = "col-xs-12 col-sm-12 col-md-12 col-lg-12 ">';
                                            
                                        
                                            echo "<div style='color:blue'> Πληρωμή ".$k."</div>";
                                            echo $row[3]." Ευρώ<br>";
                                            echo "Ημερομηνία εκτέλεσης: ".date('d-m-Y', strtotime($row[4]))."<br>";
                                            echo '<a href="">Λεπτομέρειες ></a>  &nbsp <a href="">Νέα όμοια ></a>';
                                            echo "</div>";
                                            
                                            echo "</div>";
                                            echo "<hr>";
                                        }
                                    }
                                
                                ?>
                        </div>                  
                </div>

                
            </div>
            

        </div>
        <div class = "row" style="margin-top: 2%">
                <?php include("footer.html");?>
            </div>
    </body>
</html>
