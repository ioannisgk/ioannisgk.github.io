<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

    <title>
        Νέος λογαριασμός
    </title>
        
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="styles.css" rel="stylesheet">
    </head>
    <body>  
    
    <?php
        session_start();
        
    // Αν έχει πατηθεί το κουμπάκι της υποβολής αποθηκεύουμε τα δεδομένα
    if(isset($_POST["save_logariasmos"])) {
        // Σύνδεση στην βάση δεδομένων
        include 'connect_db.php'; 
    
        // Get data from the form
        $iban = $_POST['iban'];
        $creation = $_POST['creation'];
        $poso = $_POST['poso'];
        $user_id = $_SESSION['user_id'];
        //Δημιουργία ερωτήματος        
        $query = "INSERT INTO Logariasmos (id_pelati, IBAN, Dimiourgia, Ypoloipo) VALUES ($user_id, '$iban', '$creation', $poso)";

        $result = mysqli_query($con,$query);
        if(!$result){
            mysqli_close($con);
            echo '<html><meta charset="UTF-8"><script>alert("Σφάλμα κατά την αποθήκευση.");</script></html>';
        } else{
            // Παίρνουμε το id του τελευταίου λογαριασμού
            $last_id = mysqli_insert_id($con);
            $query = "INSERT INTO Metafora (id_logariasmou1, id_logariasmou2, Poso, Hmerominia, Plirofories) VALUES ( 1, $last_id, $poso, '$creation', 'Αρχική μεταφορά')";
            $result = mysqli_query($con,$query);
            
            if(!$result){
                mysqli_close($con);
             echo '<html><meta charset="UTF-8"><script>alert("Σφάλμα κατά τη μεταφορά.");</script></html>';
            } else {
                mysqli_close($con);
                echo '<html><meta charset="UTF-8"><script>alert("Επιτυχής αποθήκευση.");</script></html>';
        
            }
        }
        echo '<html><meta charset="UTF-8"><script>document.location="main.php";</script></html>';
    } else {
        // Αλλιώς εμφανίζεται η φόρμα για την εισαγωγή δεδομένων
   ?>
    
    <div class="container-fluid">
        <div class = "row " >
            <?php include("header.html");?>
        </div> 
        <div class = "row" >
            <?php
                // Εισαγωγή του μενού
                include('menu.html');
            ?>
        </div>
        <hr> 
        <div class = "row" >
            <div class = "col-xs-2 col-sm-2 col-md-2 col-lg-2" >
            </div>

            <div class = "col-xs-6 col-sm-6 col-md-6 col-lg-6 ">
                    <h2 style="text-align: center">Δημιουργία Λογαριασμού</h2>
                    <div class="style1" style="text-align: center;">

                        <br>
                        <form class="form-signin" role="form" method="POST" action="logariasmos_new.php">
                            <label class="style2"> IBAN:</label>
                            <input type="text" name="iban" class="form-control control1" 
                                   placeholder="IBAN Λογαριασμού"
                               required autofocus>
                            <br><br>

                            <label class="style2"> Ημερομηνία δημιουργίας:</label>
                            <input type="date" name="creation" class="form-control control1" 
                               required>
                            <br><br>
                            
                            <label class="style2"> Ποσό:</label>
                            <input type="text" name="poso" class="form-control control1" 
                               required>
                            <br><br>

                            <div align="center">
                            <button class="btn btn-primary  btn-signin" type="reset" style="width: 20%;margin-left: 18%">Καθαρισμός</button>    
                            <button class="btn btn-primary  btn-signin" type="submit" name="save_logariasmos" style="width: 20%;margin-left: 8%">Αποθήκευση</button>
                            </div>

                        </form>
                    <br>
                    </div>
                </div>
            </div>
            <div class = "row" style="margin-top: 2%">
                <?php include("footer.html");?>
            </div>
        </div>
    <?php
    }
    ?>
    </body>
</html>
