<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
        <link href="styles.css" rel="stylesheet">
        
        <title> My Bank </title>
    </head>
    <body>

        <div class="container-fluid">
            <div class = "row">
                <?php include("header_1.html");?>
            </div>
            
            <div class = "row" >
                <?php
                    // Εισαγωγή του μενού
                    include('menu_1.html');
                ?>
            </div>
            <hr>
            <div class = "row" style="margin-top: 2%">
                <div class = "col-xs-12 col-sm-6 col-md-6 col-lg-6" align="center">
                        <img src="images/bank.jpg" style="width:40%">
                        <h4>Προτιμήστε τα προγράμματα της τράπεζάς μας!</h4>

                </div>

                <div class = "col-xs-12 col-sm-6 col-md-6 col-lg-6 ">
                    <div> 
                        <h4>Είσοδος στο ebanking</h4>
                    </div>
                    <br>
                        
                    <form method="POST" action="login.php">

                        <input type="email" name="email" placeholder="Όνομα χρήστη" required autofocus style="width: 40%;">
                        <br><br>
                        <input type="password" name="password" placeholder="Κωδικός χρήστη"  required style="width: 40%;">
                        <br><br>

                            <button class="btn btn-primary" type="submit" style="width: 40%; ">
                                    ΕΙΣΟΔΟΣ ΣΤΟ EBANKING
                            </button>

                    </form>
                    <br> 
                    <p>
                        <a href="">Ξεχάσατε τα στοιχεία σύνδεσης;</a>
                    </p>
                    <p>
                        <a href="register.php">Εγγραφή</a>
                    </p>
                    <br>
                </div>
            </div>  
            <div class = "row">
                    <h3> Ανακοινώσεις</h3>
            </div>
            <div class = "row">
                <div class = "col-xs-4 col-sm-4 col-md-4 col-lg-4">
                    <div class = "col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        <img src="images/bank1.jpg" width="100%">
                    </div>
                    <div class = "col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        <a href=""> Τίτλος Ανακοίνωσης 1</a>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, 
                        sed do eiusmod tempor incididunt ut labore et dolore magna 
                        aliqua. Ut enim ad minim veniam, quis nostrud exercitation 
                        ullamco laboris nisi ut aliquip ex ea commodo consequat. 
                        </p>
                    </div>
                    
                </div>
                <div class = "col-xs-4 col-sm-4 col-md-4 col-lg-4">
                    <div class = "col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        <img src="images/bank1.jpg" width="100%">
                    </div>
                    <div class = "col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        <a href=""> Τίτλος Ανακοίνωσης 2</a>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, 
                        sed do eiusmod tempor incididunt ut labore et dolore magna 
                        aliqua. Ut enim ad minim veniam, quis nostrud exercitation 
                        ullamco laboris nisi ut aliquip ex ea commodo consequat. 
                        </p>
                    </div>
                    
                </div>                
                 <div class = "col-xs-4 col-sm-4 col-md-4 col-lg-4">
                    <div class = "col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        <img src="images/bank1.jpg" width="100%">
                    </div>
                    <div class = "col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        <a href=""> Τίτλος Ανακοίνωσης 3</a>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, 
                        sed do eiusmod tempor incididunt ut labore et dolore magna 
                        aliqua. Ut enim ad minim veniam, quis nostrud exercitation 
                        ullamco laboris nisi ut aliquip ex ea commodo consequat. 
                        </p>
                    </div>
                    
                </div>                  
            </div>
            <div class = "row" style="margin-top: 2%">
                <?php include("footer.html");?>
            </div>
        </div>
    </body>
</html>
