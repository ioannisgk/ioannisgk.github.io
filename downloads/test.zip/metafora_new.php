<?php
    // Σύνδεση στην βάση δεδομένων
    include 'connect_db.php'; 
    
    // Παίρνουμε τα δεδομένα από τη φόρμα
    $logariasmos = $_POST['logariasmos'];
    $iban = $_POST['iban'];
    $poso = $_POST['poso'];
    $plirofories = $_POST['plirofories'];
    $date = $_POST['date'];
    $now = $_POST['radio1'];
    if($now == "now"){
        $date = date('Y-m-d H:i:s');
    }
    // Ελέγχουμε αν υπάρχει το ΙΒΑΝ
    $query = "SELECT * FROM Logariasmos WHERE IBAN='".$iban ."'";
    
    $result = mysqli_query($con,$query);
    $num=mysqli_num_rows($result);

    if($num == 0){
            mysqli_close($con);
            echo '<html><meta charset="UTF-8"><script>alert("Δεν υπάρχει το ΙΒΑΝ."); document.location="metafores.php";</script></html>';
    } else {
        $row = mysqli_fetch_array($result);
        $logariasmos2 = $row[0];
        // Ελέγχουμε αν υπάρχουν αρκετά χρήματα στο λογαριασμό
        $query = "SELECT Ypoloipo FROM Logariasmos WHERE id=".$logariasmos;
        $result = mysqli_query($con,$query);
        $row = mysqli_fetch_array($result);
        $ypoloipo = $row[0];

        if($ypoloipo < $poso){
            mysqli_close($con);

            echo '<html><meta charset="UTF-8"><script>alert("Δεν υπάρχει αρκετά μεγάλο ποσό."); document.location="metafores.php";</script></html>';
        } else {
        
            
            $query = "INSERT INTO Metafora(id_logariasmou1, id_logariasmou2, Poso, Hmerominia, Plirofories) VALUES ($logariasmos, $logariasmos2, $poso, '$date', '$plirofories')";
            $result = mysqli_query($con,$query);
            
            if(!$result){
                mysqli_close($con);
                echo '<html><meta charset="UTF-8"><script>alert("Σφάλμα κατά την αποθήκευση."); document.location="metafores.php";</script></html>';
            } else{
               
                // Παίρνουμε το υπόλοιπο του δεύτερου λογαριασμού
                $query = "SELECT Ypoloipo FROM Logariasmos WHERE id=".$logariasmos2;
                $result = mysqli_query($con,$query);
                $row = mysqli_fetch_array($result);
                $ypoloipo2 = $row[0];
                 // Μεταβολές των ποσών
                $query = "UPDATE Logariasmos SET Ypoloipo=".$ypoloipo."-".$poso." WHERE id=".$logariasmos;
                mysqli_query($con, $query);
                
                $query = "UPDATE Logariasmos SET Ypoloipo=".$ypoloipo2."+".$poso." WHERE id=".$logariasmos2;
                mysqli_query($con, $query);
                mysqli_close($con);
                echo '<html><meta charset="UTF-8"><script>alert("Επιτυχής αποθήκευση μεταφοράς."); document.location="main.php";</script></html>';
            }
        }
    }
?>
